package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.capgemini.beans.Person;
 

 
@Controller
public class MyController {
 
    @RequestMapping("/view")
    public @ResponseBody Person getPerson(){
    	
    	System.out.println("From constroller");
        Person person = new Person();
        person.setId(1);
        person.setName("Sachin");
        return person;
    }
 
}