package com.capgemini.view;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class Application {

	public static void main(String[] args) {
		//CustomerService customerService=new CustomerServiceImpl();
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		CustomerService customerService = context.getBean("customerService",CustomerServiceImpl.class);
		System.out.println(customerService.findAll().get(0).getFirstName());
		

	}

}
