import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		
	ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
	System.out.println("first line");
	Employee obj=(Employee)context.getBean("emp");

    System.out.println(obj.getId());
	System.out.println(obj.getName());
	for(Address add:obj.getAddress()){
		System.out.println(add.getCity());
	}
	

	}
}
